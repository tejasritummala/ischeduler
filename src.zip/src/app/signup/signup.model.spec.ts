import { Signup } from './signup.model';

describe('Signup', () => {
  it('should create an instance', () => {
    expect(new Signup()).toBeTruthy();
  });
});
